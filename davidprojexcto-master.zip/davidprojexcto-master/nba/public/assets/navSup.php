<nav>
  <ul>
    <li><a href="index.php">Home</a></li>
    <li><a href="./listarJugadores.php">Jugadores</a></li>
    <li><a href="nuevoJugador.php">Nuevo Jugador</a></li>
    <li><a href="equipos.php">Equipos</a></li>
    <li><a href="nuevoEquipo.php">Nuevo Equipo</a></li>
  </ul>
</nav>

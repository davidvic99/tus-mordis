<?php

require_once('../src/Jugador.php');
require_once('../public/assets/navSup.php');

$jugador = new Jugador();
$jugador->conectar();  
$resultado = $jugador->listaJugadores();  

$i=0;
while($todo=mysqli_fetch_assoc($resultado)){

  $id[] = $todo['codigo']; 
  $nombre[] = $todo['Nombre'];
  $Procedencia[] =$todo['Procedencia'];
  $Altura[]=$todo['Altura'];
  $Peso[]=$todo['Peso'];
  $Posicion[]=$todo['Posicion'];
  $team[]=$todo['Nombre_equipo'];
  echo "$id[$i] $nombre[$i] $Procedencia[$i] $Altura[$i] $Peso[$i] $Posicion[$i] $team[$i] <br> ";
  $i++;
}


?>
<link rel="stylesheet" href="./css/nba.css">
<link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">